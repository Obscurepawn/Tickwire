use crate::*;
use tickwire_binance::depth_sync::DepthSync;

pub struct PublicDepthClient<P, C, const L: usize, const U: usize, const B: usize> {
    sync: DepthSync<P, L, U, B>,
    clock: C,
}
impl<P: DepthPolicy, C: MonotonicClock, const L: usize, const U: usize, const B: usize>
    PublicDepthClient<P, C, L, U, B>
{
    pub fn new(config: Config, _network: NetworkConfig, clock: C) -> Result<Self> {
        Ok(Self { sync: DepthSync::new(config.depth).map_err(Error::Sync)?, clock })
    }
    pub fn start(&mut self, _permit: &mut impl PublicPermit) -> Result<()> { Ok(()) }
    pub fn poll(&mut self, _permit: &mut impl PublicPermit, _budget: PollBudget, _sink: &mut impl PublicSink) -> Result<PollReport> { Ok(PollReport::default()) }
    pub fn status(&self) -> Status {
        Status { phase: Phase::Idle, connection_epoch: 0, book_generation: self.sync.generation(), depth: self.sync.state(), last_update_id: self.sync.last_update_id(), snapshot_pending: false }
    }
    pub fn view(&mut self, age: u64) -> Result<BookView<'_>> {
        let time = self.clock.sample().map_err(|_| Error::Clock)?;
        self.sync.view(time.monotonic.nanos(), age).map_err(Error::View)
    }
    pub fn stop(&mut self, _sink: &mut impl PublicSink) -> Result<()> { Ok(()) }
    pub fn register(&mut self, _registry: &mio::Registry, _tokens: IoTokens) -> Result<()> { Ok(()) }
    pub fn reregister(&mut self, _registry: &mio::Registry, _tokens: IoTokens) -> Result<()> { Ok(()) }
}
