use std::collections::BTreeMap;
use tickwire_risk::{Fixed, futures::Bracket};
use tickwire_venue as v;

pub const MAX_ASSETS: usize = 64;
pub const MAX_INSTRUMENTS: usize = 64;
pub const MAX_ORDERS: usize = 1024;
pub const MAX_FACTS: usize = 16384;
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct AssetKey {
    pub wallet_id: u64,
    pub asset_id: u64,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct AssetAmount {
    pub key: AssetKey,
    pub amount: Fixed,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct IntentKey {
    pub epoch: u64,
    pub intent_id: u64,
}
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub struct OrderKey {
    pub intent: IntentKey,
    pub client_id: v::ClientId,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Scope {
    pub risk_domain_id: [u8; 16],
    pub venue: u32,
    pub environment: v::Environment,
    pub account: u64,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Revisions {
    pub risk: u64,
    pub fee: u64,
    pub bracket: u64,
    pub collateral: u64,
    pub valuation: u64,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AssetSnapshot {
    pub key: AssetKey,
    pub asset: v::AssetRef,
    pub free: Fixed,
    pub locked: Fixed,
    pub nontrade_locked: Fixed,
    pub exclusive_fee_pool: bool,
    /// Strategy 0 is the explicit unattributed bucket. Missing remainder goes there.
    pub ownership: Vec<(u64, Fixed)>,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PositionSnapshot {
    pub instrument_id: u64,
    pub side: v::PositionSide,
    pub quantity: Fixed,
    /// Conservative entry bound: long upper / short lower; no positive UPL is credited.
    pub entry_bound: Fixed,
    pub ownership: Vec<(u64, Fixed)>,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Snapshot {
    pub scope: Scope,
    pub account_epoch: u64,
    pub ledger_sequence: u64,
    pub revisions: Revisions,
    pub valid_until: u64,
    pub assets: Vec<AssetSnapshot>,
    pub positions: Vec<PositionSnapshot>,
    pub venue_available: Vec<(u64, Fixed)>,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FeePolicy {
    /// General, tax and special fees are rounded separately. All are nonnegative upper bounds.
    pub rates: [Fixed; 3],
    /// Trusted protocol/fee envelope bound, never inferred from LOT_SIZE.
    pub maximum_fills: u32,
    /// Optional account-exclusive third-asset pool; receiving-asset fallback is still reserved.
    pub exclusive_pool: Option<AssetKey>,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FuturesPolicy {
    pub position_mode: v::PositionMode,
    pub margin_mode: v::MarginMode,
    pub stress_low: Fixed,
    pub stress_high: Fixed,
    pub configured_leverage: Fixed,
    pub venue_leverage: Fixed,
    pub brackets: Vec<Bracket>,
    pub maintenance_addon: Fixed,
    pub exit_fee_rate: Fixed,
    pub funding_rate_abs_upper: Fixed,
    pub funding_settlements: u64,
    pub pending_outbound: Fixed,
    pub capital_buffer: Fixed,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InstrumentPolicy {
    pub instrument: v::InstrumentBinding,
    pub product: v::Product,
    pub wallet_id: u64,
    pub fees: FeePolicy,
    pub futures: Option<FuturesPolicy>,
    pub max_absolute_position: Fixed,
    pub max_gross_quantity: Fixed,
    /// Every submitting strategy needs its own explicit gross-quantity limit.
    pub strategy_limits: Vec<(u64, Fixed)>,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Catalog {
    pub entries: Vec<InstrumentPolicy>,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CapitalHold {
    pub wallet_id: u64,
    pub settlement_asset: u64,
    pub amount: Fixed,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Admission {
    pub(crate) digest: v::Hash,
    pub(crate) key: IntentKey,
    pub(crate) epoch: u64,
    pub(crate) sequence: u64,
    pub(crate) revisions: Revisions,
    pub(crate) deadline: u64,
    pub(crate) resources: Vec<AssetAmount>,
    pub(crate) capital: Vec<CapitalHold>,
    pub(crate) orders: Vec<OrderKey>,
    pub(crate) increases: bool,
}
impl Admission {
    pub fn command_digest(&self) -> v::Hash {
        self.digest
    }
    pub fn intent(&self) -> IntentKey {
        self.key
    }
    pub fn account_epoch(&self) -> u64 {
        self.epoch
    }
    pub fn ledger_sequence(&self) -> u64 {
        self.sequence
    }
    pub fn revisions(&self) -> Revisions {
        self.revisions
    }
    pub fn resources(&self) -> &[AssetAmount] {
        &self.resources
    }
    pub fn capital_holds(&self) -> &[CapitalHold] {
        &self.capital
    }
    pub fn orders(&self) -> &[OrderKey] {
        &self.orders
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AssetView {
    pub total: Fixed,
    pub reserved: Fixed,
    pub available: Fixed,
    pub deficit: Fixed,
    pub ownership: BTreeMap<u64, Fixed>,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OrderView {
    pub key: OrderKey,
    pub command_digest: v::Hash,
    pub strategy: u64,
    pub original_quantity: Fixed,
    pub filled_quantity: Fixed,
    pub remaining_quantity: Fixed,
    pub reduce_allocation: Fixed,
    pub unknown: bool,
    pub terminal: bool,
    pub fee_reconciled: bool,
    pub aborted: bool,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Applied {
    New,
    Duplicate,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Error {
    Risk(tickwire_risk::RiskError),
    InvalidSnapshot,
    Identity,
    Catalog,
    Stale,
    Frozen,
    Unsupported,
    UnboundedExecution,
    InsufficientAsset,
    InsufficientCapital,
    Limit,
    UnknownOrder,
    Conflict,
    Unreconciled,
    Capacity,
    FactAfterAbort,
}
impl From<tickwire_risk::RiskError> for Error {
    fn from(e: tickwire_risk::RiskError) -> Self {
        Self::Risk(e)
    }
}
pub type Result<T> = std::result::Result<T, Error>;
