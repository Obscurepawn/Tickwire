mod common;
use common::*;
use tickwire_account::*;
use tickwire_venue as v;
#[test]
fn linear_capital_and_venue_shadow_are_distinct_from_cash_asset_reservations() {
    let (s, c, cmd) = futures_fixture();
    let mut a = Account::from_snapshot(s, c).unwrap();
    let admission = a.admit(&canonical(cmd.clone()), 60).unwrap();
    assert_eq!(
        admission.capital_holds(),
        &[CapitalHold {
            wallet_id: 1,
            settlement_asset: 2,
            amount: units(10)
        }]
    );
    assert_eq!(a.venue_shadow(1).unwrap(), units(990));
    a.apply_event(&event(fill(&cmd, "t1", "1", "100", "100")))
        .unwrap();
    assert_eq!(a.position(12, v::PositionSide::Both).unwrap().0, units(1));
    assert_eq!(a.venue_shadow(1).unwrap(), units(990));
}
#[test]
fn reduce_allocations_cannot_share_the_same_actual_position() {
    let (mut s, c, mut cmd) = futures_fixture();
    s.positions.push(PositionSnapshot {
        instrument_id: 12,
        side: v::PositionSide::Both,
        quantity: units(5),
        entry_bound: units(100),
        ownership: vec![(8, units(5))],
    });
    let v::CommandBody::New(ref mut o) = cmd.body else {
        unreachable!()
    };
    o.side = v::Side::Sell;
    o.reduce_only = true;
    o.quantity = v::Quantity::Base(venue::d(3, 0));
    let mut a = Account::from_snapshot(s, c).unwrap();
    let first = a.admit(&canonical(cmd.clone()), 60).unwrap();
    assert_eq!(
        a.order(&first.orders()[0]).unwrap().reduce_allocation,
        units(3)
    );
    cmd.context.request.intent_id += 1;
    let v::CommandBody::New(ref mut o) = cmd.body else {
        unreachable!()
    };
    o.client_id = venue::text("second");
    assert!(a.admit(&canonical(cmd), 60).is_err());
    assert_eq!(
        a.order(&first.orders()[0]).unwrap().reduce_allocation,
        units(3)
    );
}
#[test]
fn shared_wallet_gross_limit_includes_offsetting_strategy_positions() {
    let (mut s, mut c, cmd) = futures_fixture();
    s.positions.push(PositionSnapshot {
        instrument_id: 12,
        side: v::PositionSide::Both,
        quantity: units(2),
        entry_bound: units(100),
        ownership: vec![(8, units(5)), (9, units(-3))],
    });
    c.entries[0].max_gross_quantity = units(8);
    c.entries[0].strategy_limits.push((9, units(100)));
    let mut a = Account::from_snapshot(s, c).unwrap();
    assert_eq!(a.admit(&canonical(cmd), 60), Err(Error::Limit));
}
